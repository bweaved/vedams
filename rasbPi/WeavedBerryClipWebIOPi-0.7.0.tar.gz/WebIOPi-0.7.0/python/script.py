import webiopi, os

GPIO = webiopi.GPIO

BUTTON = 7	#GPIO 7, Pin 26

NOTIFY_GPIO24 = 24	#Pin 26 

def setup():
	GPIO.setFunction(BUTTON, GPIO.IN)
	GPIO.setFunction(NOTIFY_GPIO24, GPIO.OUT)

def loop():
	if(GPIO.digitalRead(BUTTON) == GPIO.HIGH):
		os.system('sh /usr/bin/send_notification.sh 0 "Switch Pressed" "ok"')
	elif(GPIO.digitalRead(NOTIFY_GPIO24) == GPIO.HIGH):
		os.system('sh /usr/bin/send_notification.sh 0 "GPIO24 Set" "ok"')
		GPIO.digitalWrite(NOTIFY_GPIO24, GPIO.LOW)
	webiopi.sleep(1)

@webiopi.macro
def hello():
	os.system('sh /usr/bin/send_notification.sh 0 "Web Page Push Alert" "ok"')

	webiopi.sleep(1)
